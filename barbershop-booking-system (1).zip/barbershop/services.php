<?php
$pageTitle = 'รายการ & จองคิว';
$activePage = 'services';
require_once __DIR__ . '/includes/header.php';

$services = getActiveServices();

// จัดกลุ่มตามหมวดหมู่เพื่อความสวยงามและง่ายต่อการเลือก
$grouped = [];
foreach ($services as $s) {
    $grouped[$s['category'] ?: 'อื่น ๆ'][] = $s;
}
?>
<section style="padding-top:56px;">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">เลือกรายการที่ต้องการ</span>
      <h2>รายการบริการทั้งหมด</h2>
      <span class="pole-underline"></span>
      <p style="margin-top:14px;">ติ๊กเลือกบริการที่ต้องการ ระบบจะคำนวณราคารวมให้อัตโนมัติ จากนั้นกด "ไปหน้าจองคิว" เพื่อเลือกวันเวลา</p>
    </div>

    <?php if (!isLoggedIn()): ?>
      <div class="alert alert-error">
        คุณต้อง <a href="login.php" style="color:var(--brass-lt); font-weight:600;">เข้าสู่ระบบ</a>
        หรือ <a href="register.php" style="color:var(--brass-lt); font-weight:600;">สมัครสมาชิก</a>
        ก่อนจึงจะสามารถจองคิวได้ — แต่คุณสามารถเลือกดูรายการและราคาได้ก่อน
      </div>
    <?php endif; ?>

    <form action="booking.php" method="post" id="serviceForm">
      <div class="services-layout">
        <div class="service-list">
          <?php foreach ($grouped as $category => $items): ?>
            <h4 style="margin-top:22px; color:var(--brass-lt);"><?= h($category) ?></h4>
            <?php foreach ($items as $s): ?>
              <label class="service-card" data-card>
                <input type="checkbox" name="services[]" value="<?= (int) $s['id'] ?>"
                       data-name="<?= h($s['name']) ?>" data-price="<?= (float) $s['price'] ?>">
                <div class="service-thumb">
                  <?php if (!empty($s['image_path'])): ?>
                    <img src="<?= h($s['image_path']) ?>" alt="<?= h($s['name']) ?>">
                  <?php else: ?>
                    รอรูป
                  <?php endif; ?>
                </div>
                <div class="service-info">
                  <h4><?= h($s['name']) ?></h4>
                  <span class="cat"><?= $s['description'] !== '' ? h($s['description']) : 'รอเพิ่มรายละเอียด' ?></span>
                </div>
                <div class="service-price">
                  <?= $s['price'] > 0 ? formatPrice($s['price']) : '— บาท' ?>
                </div>
              </label>
            <?php endforeach; ?>
          <?php endforeach; ?>
        </div>

        <aside class="cart-box">
          <h3>💈 สรุปรายการจอง</h3>
          <div class="cart-items" id="cartItems">
            <p class="cart-empty" id="cartEmptyMsg">ยังไม่ได้เลือกรายการ</p>
          </div>
          <div class="cart-total">
            <span>ราคารวม</span>
            <span class="amount" id="cartTotal">0.00 บาท</span>
          </div>
          <div style="margin-top:20px;">
            <?php if (isLoggedIn()): ?>
              <button type="submit" class="btn btn-primary btn-block" id="submitBtn" disabled>ไปหน้าจองคิว</button>
            <?php else: ?>
              <a href="login.php" class="btn btn-primary btn-block">เข้าสู่ระบบเพื่อจองคิว</a>
            <?php endif; ?>
          </div>
        </aside>
      </div>
    </form>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
