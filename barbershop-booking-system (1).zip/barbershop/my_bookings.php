<?php
$pageTitle = 'คิวของฉัน';
$activePage = 'bookings';
require_once __DIR__ . '/includes/functions.php';
requireLogin('login.php');

$db = getDB();
$stmt = $db->prepare('SELECT * FROM bookings WHERE user_id = ? ORDER BY booking_date DESC, booking_time DESC');
$stmt->execute([$_SESSION['user_id']]);
$bookings = $stmt->fetchAll();

$statusLabel = [
    'pending'   => 'รอยืนยัน',
    'confirmed' => 'ยืนยันแล้ว',
    'completed' => 'เสร็จสิ้น',
    'cancelled' => 'ยกเลิก',
];

require_once __DIR__ . '/includes/header.php';
?>
<section style="padding-top:56px;">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">ประวัติของคุณ</span>
      <h2>คิวของฉัน</h2>
      <span class="pole-underline"></span>
    </div>

    <?php if (empty($bookings)): ?>
      <p>คุณยังไม่มีประวัติการจองคิว <a href="services.php" style="color:var(--brass-lt);">จองคิวแรกของคุณเลย</a></p>
    <?php else: ?>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>รหัส</th><th>วันที่</th><th>เวลา</th><th>ราคารวม</th><th>สถานะ</th><th>SMS</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($bookings as $b): ?>
              <tr>
                <td>#<?= $b['id'] ?></td>
                <td><?= date('d/m/Y', strtotime($b['booking_date'])) ?></td>
                <td><?= substr($b['booking_time'], 0, 5) ?> น.</td>
                <td><?= formatPrice($b['total_price']) ?></td>
                <td><span class="badge badge-<?= $b['status'] ?>"><?= $statusLabel[$b['status']] ?? $b['status'] ?></span></td>
                <td><?= $b['sms_sent'] ? '✅ ส่งแล้ว' : '—' ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
