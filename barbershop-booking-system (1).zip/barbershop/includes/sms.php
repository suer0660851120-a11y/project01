<?php
/**
 * includes/sms.php
 * ------------------------------------------------------------
 * ฟังก์ชันส่ง SMS แจ้งเตือนลูกค้าเมื่อจองคิวสำเร็จ
 *
 * หมายเหตุสำคัญ:
 * เนื่องจากผู้ให้บริการ SMS ในไทยแต่ละเจ้า (เช่น THSMS, SMSMKT,
 * Thai Bulk SMS, Twilio) มีรูปแบบ API ไม่เหมือนกัน ไฟล์นี้จึงเขียน
 * เป็นโครงสร้างกลาง (generic REST POST + Bearer token) ให้ก่อน
 * เมื่อสมัครใช้งานผู้ให้บริการจริงแล้ว ให้แก้ไขเฉพาะส่วน
 * "สร้าง payload" และ "endpoint" ให้ตรงกับเอกสาร API ของผู้ให้บริการนั้น ๆ
 * (รายละเอียดเพิ่มเติมอยู่ในคู่มือ README.md หัวข้อ "การเชื่อมต่อ SMS")
 * ------------------------------------------------------------
 */

require_once __DIR__ . '/../config/config.php';

/**
 * ส่ง SMS ไปยังเบอร์โทรที่กำหนด
 *
 * @param string $phone   เบอร์โทรผู้รับ เช่น 0812345678
 * @param string $message ข้อความที่จะส่ง
 * @return bool  true = ส่งสำเร็จ (หรือปิดระบบ SMS ไว้), false = ส่งไม่สำเร็จ
 */
function sendSMS(string $phone, string $message): bool
{
    // ถ้ายังไม่ได้เปิดใช้งาน SMS จริง (ยังไม่ตั้งค่า API) ให้บันทึก log แทนการส่งจริง
    // เพื่อให้ระบบยังทดสอบ flow การจองคิวได้แม้ยังไม่มี SMS API
    if (!defined('SMS_ENABLED') || SMS_ENABLED !== true) {
        error_log("[SMS-DISABLED] ถึง {$phone}: {$message}");
        return true;
    }

    // แปลงเบอร์ไทย 08xxxxxxxx ให้เป็นรูปแบบสากล 66xxxxxxxxx (ผู้ให้บริการส่วนใหญ่ต้องการแบบนี้)
    $internationalPhone = preg_replace('/^0/', '66', $phone);

    $payload = [
        'sender'  => SMS_SENDER_NAME,
        'to'      => $internationalPhone,
        'message' => $message,
    ];

    $ch = curl_init(SMS_API_URL);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . SMS_API_KEY,
        ],
        CURLOPT_TIMEOUT        => 10,
    ]);

    $response  = curl_exec($ch);
    $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($curlError) {
        error_log('SMS send error (cURL): ' . $curlError);
        return false;
    }

    if ($httpCode >= 200 && $httpCode < 300) {
        return true;
    }

    error_log("SMS send failed. HTTP {$httpCode}: {$response}");
    return false;
}

/** สร้างข้อความแจ้งเตือนเมื่อจองคิวสำเร็จ */
function buildBookingConfirmationMessage(string $customerName, string $date, string $time, float $total): string
{
    $shop = SHOP_NAME;
    $dateThai = date('d/m/Y', strtotime($date));
    return "[{$shop}] คุณ{$customerName} จองคิวสำเร็จ วันที่ {$dateThai} เวลา {$time} น. "
         . "ยอดรวม " . number_format($total, 2) . " บาท กรุณามาตรงเวลา ขอบคุณที่ใช้บริการค่ะ";
}
