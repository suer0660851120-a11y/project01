<?php
$pageTitle = 'หน้าแรก';
$activePage = 'home';
require_once __DIR__ . '/includes/header.php';

$galleryPreview = array_slice(getGalleryImages(), 0, 5);
$servicesPreview = array_slice(getActiveServices(), 0, 6);
?>

<section class="hero" id="home">
  <div class="container hero-grid">
    <div>
      <span class="eyebrow">ร้านตัดผมชายมาตรฐานสตูดิโอ</span>
      <h1>ตัดผมให้ดี<br>ต้อง<em>จองคิวให้เป็น</em></h1>
      <p class="hero-lead">
        จองคิวออนไลน์ล่วงหน้า เลือกรายการที่ต้องการ เห็นราคารวมก่อนถึงร้านจริง
        ไม่ต้องรอคิวหน้าร้าน พร้อมรับ SMS แจ้งเตือนยืนยันการจอง
      </p>
      <div class="hero-cta">
        <a href="services.php" class="btn btn-primary">จองคิวตอนนี้</a>
        <a href="gallery.php" class="btn btn-outline">ดูผลงานร้าน</a>
      </div>

      <div class="hero-stats">
        <div><strong>15+</strong><span>รายการบริการ</span></div>
        <div><strong>100%</strong><span>จองผ่านระบบสมาชิก</span></div>
        <div><strong>SMS</strong><span>แจ้งเตือนอัตโนมัติ</span></div>
      </div>
    </div>

    <div class="hero-frame">
      <div class="placeholder-note">
        📷<br>วางรูปหน้าร้าน / ช่างตัดผม<br>ไว้ตรงนี้ภายหลัง<br>
        <code>assets/images/hero.jpg</code>
      </div>
    </div>
  </div>
</section>

<div class="pole-divider"></div>

<section id="about">
  <div class="container">
    <div class="section-head center">
      <span class="eyebrow">ทำไมต้องจองผ่านระบบ</span>
      <h2>ทุกคิว วางแผนได้ล่วงหน้า</h2>
      <span class="pole-underline"></span>
    </div>
    <div class="grid-3">
      <div class="info-card">
        <div class="icon">🕒</div>
        <h4>เลือกวันเวลาเอง</h4>
        <p>เลือกวันและเวลาที่สะดวก ระบบกันคิวไว้ให้ทันทีที่กดยืนยัน</p>
      </div>
      <div class="info-card">
        <div class="icon">💈</div>
        <h4>เห็นราคาก่อนเสมอ</h4>
        <p>เลือกรายการที่ต้องการ ระบบคำนวณราคารวมให้อัตโนมัติก่อนยืนยันจอง</p>
      </div>
      <div class="info-card">
        <div class="icon">📲</div>
        <h4>แจ้งเตือนผ่าน SMS</h4>
        <p>ได้รับ SMS ยืนยันทันทีหลังจองสำเร็จ ไม่ลืมคิวแน่นอน</p>
      </div>
    </div>
  </div>
</section>

<section class="alt-bg" id="gallery-preview">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">ผลงานของเรา</span>
      <h2>แกลเลอรี่ตัวอย่างงาน</h2>
      <span class="pole-underline"></span>
    </div>
    <div class="gallery-grid">
      <?php foreach ($galleryPreview as $img): ?>
        <figure>
          <?php if (!empty($img['image_path'])): ?>
            <img src="<?= h($img['image_path']) ?>" alt="<?= h($img['caption']) ?>">
          <?php else: ?>
            <div class="gallery-empty">รอเพิ่มรูปภาพ<br><?= h($img['caption']) ?></div>
          <?php endif; ?>
          <figcaption><?= h($img['caption']) ?></figcaption>
        </figure>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center; margin-top:32px;">
      <a href="gallery.php" class="btn btn-outline">ดูผลงานทั้งหมด</a>
    </div>
  </div>
</section>

<section id="services-preview">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">บริการของเรา</span>
      <h2>รายการยอดนิยม</h2>
      <span class="pole-underline"></span>
    </div>
    <div class="grid-3">
      <?php foreach ($servicesPreview as $s): ?>
        <div class="info-card">
          <h4><?= h($s['name']) ?></h4>
          <p><?= $s['description'] !== '' ? h($s['description']) : 'รอเพิ่มรายละเอียดบริการ' ?></p>
          <div class="service-price"><?= $s['price'] > 0 ? formatPrice($s['price']) : 'ระบุราคาภายหลัง' ?></div>
        </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center; margin-top:32px;">
      <a href="services.php" class="btn btn-primary">ดูรายการทั้งหมด &amp; จองคิว</a>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
