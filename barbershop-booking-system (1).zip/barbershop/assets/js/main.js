// ============================================================
// THE BARBER STUDIO — main.js
// 1) เปิด/ปิดเมนูมือถือ
// 2) คำนวณตะกร้ารายการที่เลือกแบบเรียลไทม์ในหน้า services.php
// ============================================================

document.addEventListener('DOMContentLoaded', function () {

  // ---------- Mobile nav toggle ----------
  var navToggle = document.getElementById('navToggle');
  var navLinks = document.getElementById('navLinks');
  if (navToggle && navLinks) {
    navToggle.addEventListener('click', function () {
      var isOpen = navLinks.style.display === 'flex';
      navLinks.style.display = isOpen ? 'none' : 'flex';
      navLinks.style.flexDirection = 'column';
      navLinks.style.position = 'absolute';
      navLinks.style.top = '76px';
      navLinks.style.right = '24px';
      navLinks.style.background = '#201c15';
      navLinks.style.border = '1px solid rgba(237,230,214,0.12)';
      navLinks.style.padding = '16px 24px';
      navLinks.style.borderRadius = '4px';
      navLinks.style.gap = '16px';
    });
  }

  // ---------- Live booking cart ----------
  var checkboxes = document.querySelectorAll('.service-card input[type="checkbox"]');
  var cartItemsEl = document.getElementById('cartItems');
  var cartTotalEl = document.getElementById('cartTotal');
  var submitBtn = document.getElementById('submitBtn');

  if (checkboxes.length && cartItemsEl && cartTotalEl) {

    function renderCart() {
      var selected = Array.prototype.filter.call(checkboxes, function (cb) { return cb.checked; });
      var total = 0;

      if (selected.length === 0) {
        cartItemsEl.innerHTML = '<p class="cart-empty">ยังไม่ได้เลือกรายการ</p>';
      } else {
        var rows = selected.map(function (cb) {
          var price = parseFloat(cb.dataset.price) || 0;
          total += price;
          return '<div class="cart-row"><span>' + cb.dataset.name + '</span><span>' +
                 price.toLocaleString('th-TH', { minimumFractionDigits: 2 }) + ' บาท</span></div>';
        });
        cartItemsEl.innerHTML = rows.join('');
      }

      cartTotalEl.textContent = total.toLocaleString('th-TH', { minimumFractionDigits: 2 }) + ' บาท';

      // อัปเดตกรอบ card ที่ถูกเลือกให้ไฮไลต์
      checkboxes.forEach(function (cb) {
        var card = cb.closest('.service-card');
        if (card) card.classList.toggle('checked', cb.checked);
      });

      if (submitBtn) {
        submitBtn.disabled = selected.length === 0;
      }
    }

    checkboxes.forEach(function (cb) {
      cb.addEventListener('change', renderCart);
    });

    renderCart();
  }
});
