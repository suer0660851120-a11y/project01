<?php
$pageTitle = 'เข้าสู่ระบบ';
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$errors = [];
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!checkCsrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'เซสชันหมดอายุ กรุณาลองใหม่อีกครั้ง';
    }

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = 'กรุณากรอกอีเมลและรหัสผ่าน';
    }

    if (empty($errors)) {
        $db = getDB();
        $stmt = $db->prepare('SELECT * FROM users WHERE email = ?');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password_hash'])) {
            $errors[] = 'อีเมลหรือรหัสผ่านไม่ถูกต้อง';
        } else {
            session_regenerate_id(true);
            $_SESSION['user_id'] = (int) $user['id'];
            $_SESSION['is_admin'] = (int) $user['is_admin'];

            $redirect = $_SESSION['redirect_after_login'] ?? 'index.php';
            unset($_SESSION['redirect_after_login']);
            header('Location: ' . $redirect);
            exit;
        }
    }
}

require_once __DIR__ . '/includes/header.php';
?>
<section style="padding-top:80px;">
  <div class="container">
    <div class="form-card">
      <div class="section-head center" style="margin-bottom:24px;">
        <span class="eyebrow">ยินดีต้อนรับกลับ</span>
        <h2>เข้าสู่ระบบ</h2>
        <span class="pole-underline"></span>
      </div>

      <?php foreach ($errors as $err): ?>
        <div class="alert alert-error"><?= h($err) ?></div>
      <?php endforeach; ?>

      <form method="post" action="login.php">
        <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">
        <div class="field">
          <label>อีเมล</label>
          <input type="email" name="email" value="<?= h($email) ?>" required autofocus>
        </div>
        <div class="field">
          <label>รหัสผ่าน</label>
          <input type="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary btn-block">เข้าสู่ระบบ</button>
      </form>

      <div class="form-foot">
        ยังไม่มีบัญชี? <a href="register.php">สมัครสมาชิก</a>
      </div>
    </div>
  </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
