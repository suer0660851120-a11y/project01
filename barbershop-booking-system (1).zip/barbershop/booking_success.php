<?php
$pageTitle = 'จองคิวสำเร็จ';
require_once __DIR__ . '/includes/functions.php';
requireLogin('login.php');

$bookingId = (int) ($_GET['id'] ?? 0);
$db = getDB();

$stmt = $db->prepare('SELECT * FROM bookings WHERE id = ? AND user_id = ?');
$stmt->execute([$bookingId, $_SESSION['user_id']]);
$booking = $stmt->fetch();

if (!$booking) {
    header('Location: index.php');
    exit;
}

$itemsStmt = $db->prepare('SELECT * FROM booking_items WHERE booking_id = ?');
$itemsStmt->execute([$bookingId]);
$items = $itemsStmt->fetchAll();

require_once __DIR__ . '/includes/header.php';
?>
<section style="padding-top:70px; text-align:center;">
  <div class="container">
    <div style="font-size:56px;">✅</div>
    <h2>จองคิวสำเร็จแล้ว!</h2>
    <p>เราได้บันทึกการจองของคุณเรียบร้อย <?= $booking['sms_sent'] ? 'และส่ง SMS ยืนยันไปยังเบอร์โทรของคุณแล้ว' : '' ?></p>

    <div class="form-card wide" style="text-align:left; margin-top:32px;">
      <h4 style="color:var(--brass-lt);">รายละเอียดการจอง #<?= $booking['id'] ?></h4>
      <div class="table-wrap" style="margin:16px 0;">
        <table>
          <thead><tr><th>รายการ</th><th>ราคา</th></tr></thead>
          <tbody>
            <?php foreach ($items as $item): ?>
              <tr><td><?= h($item['service_name']) ?></td><td><?= formatPrice($item['price']) ?></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p>👤 ชื่อผู้จอง: <strong><?= h($booking['customer_name']) ?></strong></p>
      <p>📞 เบอร์ติดต่อ: <strong><?= h($booking['customer_phone']) ?></strong></p>
      <p>📅 วันเวลา: <strong><?= date('d/m/Y', strtotime($booking['booking_date'])) ?> เวลา <?= substr($booking['booking_time'], 0, 5) ?> น.</strong></p>
      <p>💰 ราคารวม: <strong style="color:var(--brass);"><?= formatPrice($booking['total_price']) ?></strong></p>
      <p>สถานะ: <span class="badge badge-<?= $booking['status'] ?>"><?= h($booking['status']) ?></span></p>
    </div>

    <div style="margin-top:28px;">
      <a href="my_bookings.php" class="btn btn-outline">ดูคิวของฉันทั้งหมด</a>
      <a href="index.php" class="btn btn-primary">กลับหน้าแรก</a>
    </div>
  </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
