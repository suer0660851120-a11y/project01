<?php
/**
 * config/config.php
 * ------------------------------------------------------------
 * ค่าตั้งค่าทั่วไปของเว็บไซต์ + ค่าตั้งค่า SMS API
 * ------------------------------------------------------------
 */

session_start();

// ---------- ข้อมูลร้าน (แก้ไขได้ตามต้องการ) ----------
define('SHOP_NAME', 'THE BARBER STUDIO');
define('SHOP_TAGLINE', 'ตัดผมชาย สไตล์คลาสสิก ใส่ใจทุกรายละเอียด');
define('SHOP_ADDRESS', 'แก้ไขที่อยู่ร้านของคุณที่นี่');
define('SHOP_PHONE', '08x-xxx-xxxx');
define('SHOP_OPEN_HOURS', 'เปิดทุกวัน 10:00 - 20:00 น.');
define('SHOP_LINE_ID', '@yourshop');

// ---------- ค่าตั้งค่า SMS Gateway ----------
// ตัวอย่างนี้เขียนให้รองรับผู้ให้บริการ SMS ทั่วไปที่รับ REST API แบบ POST
// (เช่น THSMS, SMSMKT, Thai Bulk SMS ฯลฯ) กรุณาแก้ไขค่าตาม provider จริงที่ใช้งาน
// ดูรายละเอียดเพิ่มเติมที่ includes/sms.php และคู่มือ README.md
define('SMS_API_URL', 'https://api.your-sms-provider.com/v1/send'); // URL ของผู้ให้บริการ SMS
define('SMS_API_KEY', 'YOUR_SMS_API_KEY_HERE');
define('SMS_API_SECRET', 'YOUR_SMS_API_SECRET_HERE');
define('SMS_SENDER_NAME', 'BarberShop');
define('SMS_ENABLED', false); // ตั้งเป็น true เมื่อกรอกค่า API จริงแล้ว

// ---------- Path ----------
define('BASE_URL', ''); // ถ้าเว็บอยู่ในโฟลเดอร์ย่อย เช่น http://localhost/barbershop ให้เปลี่ยนเป็น '/barbershop'
