<?php
/**
 * config/database.php
 * ------------------------------------------------------------
 * ตั้งค่าการเชื่อมต่อฐานข้อมูล MySQL ผ่าน PDO
 * แก้ไขค่าด้านล่างให้ตรงกับเครื่อง/โฮสติ้งของคุณ
 * ------------------------------------------------------------
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'barbershop_db');
define('DB_USER', 'root');      // เปลี่ยนเป็น username ฐานข้อมูลของคุณ
define('DB_PASS', '');          // เปลี่ยนเป็น password ฐานข้อมูลของคุณ
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // ไม่แสดง error ดิบให้ผู้ใช้เห็นเพื่อความปลอดภัย แต่ log ไว้แทน
            error_log('Database connection failed: ' . $e->getMessage());
            die('ขออภัย ระบบไม่สามารถเชื่อมต่อฐานข้อมูลได้ในขณะนี้ กรุณาลองใหม่ภายหลัง');
        }
    }

    return $pdo;
}
