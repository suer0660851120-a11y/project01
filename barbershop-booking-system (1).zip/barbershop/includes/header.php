<?php
/**
 * includes/header.php
 * เรียกใช้ตัวแปร $pageTitle (optional) และ $activePage (optional) ก่อน include ไฟล์นี้
 */
require_once __DIR__ . '/functions.php';
$user = currentUser();
$activePage = $activePage ?? '';
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($pageTitle ?? SHOP_NAME) ?> | <?= h(SHOP_NAME) ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body>

<header class="navbar">
  <div class="container">
    <a href="<?= BASE_URL ?>/index.php" class="brand">THE <span>BARBER</span> STUDIO</a>

    <ul class="nav-links" id="navLinks">
      <li><a href="<?= BASE_URL ?>/index.php#home" class="<?= $activePage === 'home' ? 'active' : '' ?>">หน้าแรก</a></li>
      <li><a href="<?= BASE_URL ?>/gallery.php" class="<?= $activePage === 'gallery' ? 'active' : '' ?>">แกลเลอรี่</a></li>
      <li><a href="<?= BASE_URL ?>/services.php" class="<?= $activePage === 'services' ? 'active' : '' ?>">รายการ &amp; จองคิว</a></li>
      <?php if (isLoggedIn()): ?>
        <li><a href="<?= BASE_URL ?>/my_bookings.php" class="<?= $activePage === 'bookings' ? 'active' : '' ?>">คิวของฉัน</a></li>
      <?php endif; ?>
    </ul>

    <div class="nav-user">
      <?php if ($user): ?>
        <span class="eyebrow" style="color:var(--cream-dim); font-size:13px;">สวัสดี, <?= h($user['full_name']) ?></span>
        <a href="<?= BASE_URL ?>/logout.php" class="btn btn-outline">ออกจากระบบ</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/login.php" class="btn btn-outline">เข้าสู่ระบบ</a>
        <a href="<?= BASE_URL ?>/register.php" class="btn btn-primary">สมัครสมาชิก</a>
      <?php endif; ?>
      <button class="nav-toggle" id="navToggle" aria-label="เมนู">☰</button>
    </div>
  </div>
</header>
