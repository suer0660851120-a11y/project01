<?php
$pageTitle = 'แกลเลอรี่ผลงาน';
$activePage = 'gallery';
require_once __DIR__ . '/includes/header.php';

$images = getGalleryImages();
?>
<section style="padding-top:56px;">
  <div class="container">
    <div class="section-head center">
      <span class="eyebrow">ผลงานของเรา</span>
      <h2>แกลเลอรี่ผลงานร้าน</h2>
      <span class="pole-underline"></span>
      <p style="margin-top:14px;">ตัวอย่างผลงานทรงผมจริงจากช่างของเรา อัปเดตใหม่ทุกเดือน</p>
    </div>

    <div class="gallery-grid">
      <?php foreach ($images as $img): ?>
        <figure>
          <?php if (!empty($img['image_path'])): ?>
            <img src="<?= h($img['image_path']) ?>" alt="<?= h($img['caption']) ?>">
          <?php else: ?>
            <div class="gallery-empty">รอเพิ่มรูปภาพ<br><?= h($img['caption']) ?></div>
          <?php endif; ?>
          <figcaption><?= h($img['caption']) ?></figcaption>
        </figure>
      <?php endforeach; ?>
      <?php if (empty($images)): ?>
        <p>ยังไม่มีรูปภาพในแกลเลอรี่ กรุณาเพิ่มข้อมูลในตาราง <code>gallery</code></p>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
