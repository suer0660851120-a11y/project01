<?php
/**
 * admin/services.php
 * หน้าแอดมินสำหรับแก้ไขรายการบริการ 15 รายการที่เตรียมไว้
 * (ชื่อ, รายละเอียด, ราคา, path รูปภาพ, หมวดหมู่, เปิด/ปิดใช้งาน)
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$db = getDB();
$saved = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && checkCsrf($_POST['csrf_token'] ?? '')) {
    $stmt = $db->prepare(
        'UPDATE services SET name=?, description=?, price=?, image_path=?, category=?, is_active=? WHERE id=?'
    );
    foreach ($_POST['service'] as $id => $data) {
        $stmt->execute([
            trim($data['name']),
            trim($data['description']),
            (float) $data['price'],
            trim($data['image_path']),
            trim($data['category']),
            isset($data['is_active']) ? 1 : 0,
            (int) $id,
        ]);
    }
    $saved = true;
}

$services = $db->query('SELECT * FROM services ORDER BY sort_order ASC, id ASC')->fetchAll();
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>แอดมิน - จัดการรายการบริการ</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header class="navbar"><div class="container">
  <a href="../index.php" class="brand">THE <span>BARBER</span> STUDIO — <small style="font-size:13px;">ADMIN</small></a>
  <div class="nav-user">
    <a href="bookings.php" class="btn btn-outline">จัดการคิว</a>
    <a href="../logout.php" class="btn btn-outline">ออกจากระบบ</a>
  </div>
</div></header>

<section style="padding-top:48px;">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">แผงควบคุมแอดมิน</span>
      <h2>จัดการรายการบริการ (15 รายการ)</h2>
      <span class="pole-underline"></span>
      <p style="margin-top:14px;">กรอกชื่อรายการ รายละเอียด ราคา และ path รูปภาพ (เช่น <code>assets/images/services/1.jpg</code>) แล้วกดบันทึก</p>
    </div>

    <?php if ($saved): ?>
      <div class="alert alert-success">บันทึกรายการบริการเรียบร้อยแล้ว</div>
    <?php endif; ?>

    <form method="post">
      <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">
      <div class="table-wrap">
        <table>
          <thead>
            <tr><th>#</th><th>ชื่อรายการ</th><th>รายละเอียด</th><th>ราคา (บาท)</th><th>Path รูปภาพ</th><th>หมวดหมู่</th><th>เปิดใช้งาน</th></tr>
          </thead>
          <tbody>
            <?php foreach ($services as $s): ?>
              <tr>
                <td><?= $s['sort_order'] ?></td>
                <td><input type="text" name="service[<?= $s['id'] ?>][name]" value="<?= h($s['name']) ?>"></td>
                <td><input type="text" name="service[<?= $s['id'] ?>][description]" value="<?= h($s['description']) ?>"></td>
                <td style="width:110px;"><input type="number" step="0.01" name="service[<?= $s['id'] ?>][price]" value="<?= $s['price'] ?>"></td>
                <td><input type="text" name="service[<?= $s['id'] ?>][image_path]" value="<?= h($s['image_path']) ?>" placeholder="assets/images/services/…"></td>
                <td><input type="text" name="service[<?= $s['id'] ?>][category]" value="<?= h($s['category']) ?>"></td>
                <td style="text-align:center;"><input type="checkbox" name="service[<?= $s['id'] ?>][is_active]" <?= $s['is_active'] ? 'checked' : '' ?>></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div style="margin-top:24px;">
        <button type="submit" class="btn btn-primary">บันทึกการเปลี่ยนแปลง</button>
      </div>
    </form>
  </div>
</section>
</body>
</html>
