<?php
$pageTitle = 'จองคิว';
$activePage = 'services';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/sms.php';

requireLogin('login.php');
$user = currentUser();
$db = getDB();
$errors = [];

// ------------------------------------------------------------
// STAGE 2: ผู้ใช้กดยืนยันการจองจากฟอร์มรายละเอียด (มี confirm=1)
// ------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm'])) {

    if (!checkCsrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'เซสชันหมดอายุ กรุณาลองใหม่อีกครั้ง';
    }

    $serviceIds = array_map('intval', $_POST['service_ids'] ?? []);
    $customerName = trim($_POST['customer_name'] ?? '');
    $customerPhone = trim($_POST['customer_phone'] ?? '');
    $bookingDate = $_POST['booking_date'] ?? '';
    $bookingTime = $_POST['booking_time'] ?? '';
    $note = trim($_POST['note'] ?? '');

    if (empty($serviceIds)) {
        $errors[] = 'กรุณาเลือกอย่างน้อย 1 รายการบริการ';
    }
    if ($customerName === '') {
        $errors[] = 'กรุณากรอกชื่อผู้จอง';
    }
    if (!isValidThaiPhone($customerPhone)) {
        $errors[] = 'กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง (เช่น 0812345678)';
    }
    if ($bookingDate === '' || strtotime($bookingDate) < strtotime(date('Y-m-d'))) {
        $errors[] = 'กรุณาเลือกวันที่จองให้ถูกต้อง (ต้องไม่ใช่วันที่ผ่านมาแล้ว)';
    }
    if ($bookingTime === '') {
        $errors[] = 'กรุณาเลือกเวลาที่ต้องการจอง';
    }

    $placeholders = implode(',', array_fill(0, count($serviceIds), '?'));
    $selectedServices = [];
    if (empty($errors) && !empty($serviceIds)) {
        $stmt = $db->prepare("SELECT * FROM services WHERE id IN ($placeholders) AND is_active = 1");
        $stmt->execute($serviceIds);
        $selectedServices = $stmt->fetchAll();
        if (count($selectedServices) !== count($serviceIds)) {
            $errors[] = 'มีรายการบริการบางรายการไม่ถูกต้องหรือถูกปิดใช้งานแล้ว';
        }
    }

    if (empty($errors)) {
        $total = array_sum(array_column($selectedServices, 'price'));

        try {
            $db->beginTransaction();

            $stmt = $db->prepare(
                'INSERT INTO bookings (user_id, customer_name, customer_phone, booking_date, booking_time, total_price, note)
                 VALUES (?, ?, ?, ?, ?, ?, ?)'
            );
            $stmt->execute([$user['id'], $customerName, $customerPhone, $bookingDate, $bookingTime, $total, $note]);
            $bookingId = (int) $db->lastInsertId();

            $itemStmt = $db->prepare(
                'INSERT INTO booking_items (booking_id, service_id, service_name, price) VALUES (?, ?, ?, ?)'
            );
            foreach ($selectedServices as $s) {
                $itemStmt->execute([$bookingId, $s['id'], $s['name'], $s['price']]);
            }

            $db->commit();

            // ส่ง SMS แจ้งเตือนยืนยันการจอง (ดู includes/sms.php)
            $message = buildBookingConfirmationMessage($customerName, $bookingDate, $bookingTime, $total);
            $smsOk = sendSMS($customerPhone, $message);
            if ($smsOk) {
                $db->prepare('UPDATE bookings SET sms_sent = 1 WHERE id = ?')->execute([$bookingId]);
            }

            header('Location: booking_success.php?id=' . $bookingId);
            exit;

        } catch (Exception $e) {
            $db->rollBack();
            error_log('Booking insert failed: ' . $e->getMessage());
            $errors[] = 'เกิดข้อผิดพลาดในการบันทึกการจอง กรุณาลองใหม่อีกครั้ง';
        }
    }

    // ถ้ามี error ให้ใช้ข้อมูลเดิมแสดงฟอร์มอีกครั้ง
    $stageTwoData = compact('customerName', 'customerPhone', 'bookingDate', 'bookingTime', 'note');
    if (!empty($serviceIds)) {
        $placeholders = implode(',', array_fill(0, count($serviceIds), '?'));
        $stmt = $db->prepare("SELECT * FROM services WHERE id IN ($placeholders)");
        $stmt->execute($serviceIds);
        $selectedServices = $stmt->fetchAll();
    }

// ------------------------------------------------------------
// STAGE 1: มาจากหน้า services.php ด้วยรายการ services[] ที่เลือก
// ------------------------------------------------------------
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['services'])) {

    $serviceIds = array_map('intval', $_POST['services']);
    if (empty($serviceIds)) {
        header('Location: services.php');
        exit;
    }
    $placeholders = implode(',', array_fill(0, count($serviceIds), '?'));
    $stmt = $db->prepare("SELECT * FROM services WHERE id IN ($placeholders) AND is_active = 1");
    $stmt->execute($serviceIds);
    $selectedServices = $stmt->fetchAll();

    $stageTwoData = [
        'customerName'  => $user['full_name'],
        'customerPhone' => $user['phone'],
        'bookingDate'   => '',
        'bookingTime'   => '',
        'note'          => '',
    ];

} else {
    // ไม่มีข้อมูลรายการที่เลือกมาเลย ให้กลับไปเลือกใหม่
    header('Location: services.php');
    exit;
}

$total = array_sum(array_column($selectedServices, 'price'));

require_once __DIR__ . '/includes/header.php';
?>
<section style="padding-top:56px;">
  <div class="container">
    <div class="section-head center">
      <span class="eyebrow">ขั้นตอนสุดท้าย</span>
      <h2>ยืนยันการจองคิว</h2>
      <span class="pole-underline"></span>
    </div>

    <div class="form-card wide">
      <?php foreach ($errors as $err): ?>
        <div class="alert alert-error"><?= h($err) ?></div>
      <?php endforeach; ?>

      <h4 style="color:var(--brass-lt);">รายการที่เลือก</h4>
      <div class="table-wrap" style="margin-bottom:24px;">
        <table>
          <thead><tr><th>รายการ</th><th>ราคา</th></tr></thead>
          <tbody>
            <?php foreach ($selectedServices as $s): ?>
              <tr><td><?= h($s['name']) ?></td><td><?= formatPrice($s['price']) ?></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <p style="text-align:right; font-family:var(--font-display); font-size:20px;">
        ราคารวมทั้งหมด: <strong style="color:var(--brass);"><?= formatPrice($total) ?></strong>
      </p>

      <form method="post" action="booking.php">
        <input type="hidden" name="confirm" value="1">
        <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">
        <?php foreach ($selectedServices as $s): ?>
          <input type="hidden" name="service_ids[]" value="<?= (int) $s['id'] ?>">
        <?php endforeach; ?>

        <div class="field-row">
          <div class="field">
            <label>ชื่อ-นามสกุลผู้จอง</label>
            <input type="text" name="customer_name" value="<?= h($stageTwoData['customerName']) ?>" required>
          </div>
          <div class="field">
            <label>เบอร์โทรศัพท์</label>
            <input type="tel" name="customer_phone" value="<?= h($stageTwoData['customerPhone']) ?>" placeholder="0812345678" required>
          </div>
        </div>

        <div class="field-row">
          <div class="field">
            <label>วันที่ต้องการจอง</label>
            <input type="date" name="booking_date" min="<?= date('Y-m-d') ?>" value="<?= h($stageTwoData['bookingDate']) ?>" required>
          </div>
          <div class="field">
            <label>เวลาที่ต้องการ</label>
            <input type="time" name="booking_time" min="10:00" max="20:00" value="<?= h($stageTwoData['bookingTime']) ?>" required>
          </div>
        </div>

        <div class="field">
          <label>หมายเหตุเพิ่มเติม (ถ้ามี)</label>
          <textarea name="note" placeholder="เช่น ต้องการช่างคนไหนเป็นพิเศษ"><?= h($stageTwoData['note']) ?></textarea>
        </div>

        <button type="submit" class="btn btn-primary btn-block">ยืนยันการจองคิว</button>
      </form>
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
