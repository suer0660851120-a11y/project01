<?php
/**
 * admin/bookings.php
 * หน้าแอดมินสำหรับดูและจัดการคิวทั้งหมด (ต้องเป็นสมาชิกที่มี is_admin = 1)
 * เข้าใช้งานด้วยบัญชีตัวอย่าง: admin@barbershop.local / admin1234 (ดู database.sql)
 */
require_once __DIR__ . '/../includes/functions.php';
requireAdmin();

$db = getDB();

// อัปเดตสถานะคิว
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    if (checkCsrf($_POST['csrf_token'] ?? '')) {
        $bookingId = (int) $_POST['booking_id'];
        $status = $_POST['status'];
        if (in_array($status, ['pending', 'confirmed', 'completed', 'cancelled'], true)) {
            $db->prepare('UPDATE bookings SET status = ? WHERE id = ?')->execute([$status, $bookingId]);
        }
    }
    header('Location: bookings.php');
    exit;
}

$bookings = $db->query(
    'SELECT b.*, u.email FROM bookings b JOIN users u ON u.id = b.user_id ORDER BY b.booking_date DESC, b.booking_time DESC'
)->fetchAll();

$statusLabel = [
    'pending' => 'รอยืนยัน', 'confirmed' => 'ยืนยันแล้ว', 'completed' => 'เสร็จสิ้น', 'cancelled' => 'ยกเลิก',
];
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>แอดมิน - จัดการคิว</title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<header class="navbar"><div class="container">
  <a href="../index.php" class="brand">THE <span>BARBER</span> STUDIO — <small style="font-size:13px;">ADMIN</small></a>
  <div class="nav-user">
    <a href="services.php" class="btn btn-outline">จัดการรายการบริการ</a>
    <a href="../logout.php" class="btn btn-outline">ออกจากระบบ</a>
  </div>
</div></header>

<section style="padding-top:48px;">
  <div class="container">
    <div class="section-head">
      <span class="eyebrow">แผงควบคุมแอดมิน</span>
      <h2>จัดการคิวทั้งหมด</h2>
      <span class="pole-underline"></span>
    </div>

    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>รหัส</th><th>ลูกค้า</th><th>อีเมล</th><th>เบอร์โทร</th><th>วันเวลา</th><th>ราคารวม</th><th>สถานะ</th><th>เปลี่ยนสถานะ</th></tr>
        </thead>
        <tbody>
          <?php foreach ($bookings as $b): ?>
            <tr>
              <td>#<?= $b['id'] ?></td>
              <td><?= h($b['customer_name']) ?></td>
              <td><?= h($b['email']) ?></td>
              <td><?= h($b['customer_phone']) ?></td>
              <td><?= date('d/m/Y', strtotime($b['booking_date'])) ?> <?= substr($b['booking_time'],0,5) ?> น.</td>
              <td><?= formatPrice($b['total_price']) ?></td>
              <td><span class="badge badge-<?= $b['status'] ?>"><?= $statusLabel[$b['status']] ?></span></td>
              <td>
                <form method="post" style="display:flex; gap:6px;">
                  <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">
                  <input type="hidden" name="booking_id" value="<?= $b['id'] ?>">
                  <select name="status">
                    <?php foreach ($statusLabel as $key => $label): ?>
                      <option value="<?= $key ?>" <?= $key === $b['status'] ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                  </select>
                  <button type="submit" name="update_status" value="1" class="btn btn-outline" style="padding:8px 14px; font-size:13px;">บันทึก</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (empty($bookings)): ?>
            <tr><td colspan="8">ยังไม่มีการจองคิวเข้ามา</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</section>
</body>
</html>
