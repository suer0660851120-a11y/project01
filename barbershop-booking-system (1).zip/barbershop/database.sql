-- ============================================================
-- ฐานข้อมูลระบบจองคิวร้านตัดผม (Barbershop Queue Booking System)
-- ใช้กับ MySQL / MariaDB
-- วิธีติดตั้ง: นำเข้าไฟล์นี้ผ่าน phpMyAdmin หรือคำสั่ง
--   mysql -u root -p < database.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS barbershop_db
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE barbershop_db;

-- ------------------------------------------------------------
-- ตาราง users : เก็บข้อมูลสมาชิก
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(150) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    phone         VARCHAR(20)  NOT NULL,
    age           INT NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    is_admin      TINYINT(1) NOT NULL DEFAULT 0,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- ตาราง services : รายการบริการของร้าน (เตรียมไว้ 15 รายการ)
-- name / price / image_path เป็นค่าว่าง ผู้ใช้งานสามารถแก้ไขเพิ่มเติมภายหลังได้
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS services (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    name         VARCHAR(150) NOT NULL DEFAULT '',
    description  VARCHAR(255) NOT NULL DEFAULT '',
    price        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    image_path   VARCHAR(255) NOT NULL DEFAULT '',
    category     VARCHAR(100) NOT NULL DEFAULT '',
    is_active    TINYINT(1) NOT NULL DEFAULT 1,
    sort_order   INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- เตรียมแถวว่างไว้ 15 รายการ ให้ผู้ใช้งานกรอกชื่อ/ราคา/รูปภาพเองภายหลัง
INSERT INTO services (name, description, price, image_path, category, sort_order) VALUES
('รายการที่ 1',  '', 0.00, '', 'ตัดผม', 1),
('รายการที่ 2',  '', 0.00, '', 'ตัดผม', 2),
('รายการที่ 3',  '', 0.00, '', 'ตัดผม', 3),
('รายการที่ 4',  '', 0.00, '', 'สระผม', 4),
('รายการที่ 5',  '', 0.00, '', 'สระผม', 5),
('รายการที่ 6',  '', 0.00, '', 'โกนหนวด', 6),
('รายการที่ 7',  '', 0.00, '', 'โกนหนวด', 7),
('รายการที่ 8',  '', 0.00, '', 'ทำสีผม', 8),
('รายการที่ 9',  '', 0.00, '', 'ทำสีผม', 9),
('รายการที่ 10', '', 0.00, '', 'ดัดผม', 10),
('รายการที่ 11', '', 0.00, '', 'ดัดผม', 11),
('รายการที่ 12', '', 0.00, '', 'สปาผม', 12),
('รายการที่ 13', '', 0.00, '', 'สปาผม', 13),
('รายการที่ 14', '', 0.00, '', 'แพ็กเกจพิเศษ', 14),
('รายการที่ 15', '', 0.00, '', 'แพ็กเกจพิเศษ', 15);

-- ------------------------------------------------------------
-- ตาราง bookings : ข้อมูลการจองคิวแต่ละครั้ง
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bookings (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    user_id         INT NOT NULL,
    customer_name   VARCHAR(150) NOT NULL,
    customer_phone  VARCHAR(20)  NOT NULL,
    booking_date    DATE NOT NULL,
    booking_time    TIME NOT NULL,
    total_price     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status          ENUM('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
    note            VARCHAR(255) NOT NULL DEFAULT '',
    sms_sent        TINYINT(1) NOT NULL DEFAULT 0,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- ตาราง booking_items : รายการบริการที่เลือกในแต่ละคิว (เก็บราคา ณ เวลาจอง)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS booking_items (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    booking_id  INT NOT NULL,
    service_id  INT NOT NULL,
    service_name VARCHAR(150) NOT NULL,
    price       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- ตาราง gallery : รูปผลงานร้าน (แสดงในหน้าแกลเลอรี่)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS gallery (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    image_path  VARCHAR(255) NOT NULL DEFAULT '',
    caption     VARCHAR(150) NOT NULL DEFAULT '',
    sort_order  INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO gallery (image_path, caption, sort_order) VALUES
('', 'ผลงานที่ 1', 1),
('', 'ผลงานที่ 2', 2),
('', 'ผลงานที่ 3', 3),
('', 'ผลงานที่ 4', 4),
('', 'ผลงานที่ 5', 5),
('', 'ผลงานที่ 6', 6);

-- ------------------------------------------------------------
-- สร้างบัญชีแอดมินตัวอย่าง (อีเมล: admin@barbershop.local / รหัสผ่าน: admin1234)
-- ควรเปลี่ยนรหัสผ่านทันทีหลังติดตั้งจริง!
-- แฮชนี้สร้างจาก password_hash('admin1234', PASSWORD_DEFAULT)
-- ------------------------------------------------------------
INSERT INTO users (full_name, email, phone, age, password_hash, is_admin) VALUES
('ผู้ดูแลระบบ', 'admin@barbershop.local', '0800000000', 30,
 '$2b$10$MUqqAklwFe0SnzDrYd3mhONdEq6YBaYC9961cLDCKIi6OKHHtwj5y', 1);
