<?php
$pageTitle = 'สมัครสมาชิก';
require_once __DIR__ . '/includes/functions.php';

if (isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$errors = [];
$values = ['full_name' => '', 'email' => '', 'phone' => '', 'age' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!checkCsrf($_POST['csrf_token'] ?? '')) {
        $errors[] = 'เซสชันหมดอายุ กรุณาลองใหม่อีกครั้ง';
    }

    $values['full_name'] = trim($_POST['full_name'] ?? '');
    $values['email']     = trim($_POST['email'] ?? '');
    $values['phone']     = trim($_POST['phone'] ?? '');
    $values['age']       = trim($_POST['age'] ?? '');
    $password  = $_POST['password'] ?? '';
    $password2 = $_POST['password_confirm'] ?? '';

    if ($values['full_name'] === '' || mb_strlen($values['full_name']) < 3) {
        $errors[] = 'กรุณากรอกชื่อ-นามสกุลจริงให้ครบถ้วน';
    }
    if (!filter_var($values['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'กรุณากรอกอีเมลให้ถูกต้อง';
    }
    if (!isValidThaiPhone($values['phone'])) {
        $errors[] = 'กรุณากรอกเบอร์โทรศัพท์ให้ถูกต้อง (เช่น 0812345678)';
    }
    if (!ctype_digit($values['age']) || (int) $values['age'] < 15 || (int) $values['age'] > 100) {
        $errors[] = 'กรุณากรอกอายุที่ถูกต้อง (15-100 ปี)';
    }
    if (strlen($password) < 6) {
        $errors[] = 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร';
    }
    if ($password !== $password2) {
        $errors[] = 'รหัสผ่านทั้งสองช่องไม่ตรงกัน';
    }

    if (empty($errors)) {
        $db = getDB();
        $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->execute([$values['email']]);
        if ($stmt->fetch()) {
            $errors[] = 'อีเมลนี้มีผู้ใช้งานสมัครสมาชิกไว้แล้ว';
        }
    }

    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $db->prepare(
            'INSERT INTO users (full_name, email, phone, age, password_hash) VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([$values['full_name'], $values['email'], $values['phone'], (int) $values['age'], $hash]);

        $_SESSION['user_id'] = (int) $db->lastInsertId();
        $_SESSION['is_admin'] = 0;

        $redirect = $_SESSION['redirect_after_login'] ?? 'index.php';
        unset($_SESSION['redirect_after_login']);
        header('Location: ' . $redirect);
        exit;
    }
}

require_once __DIR__ . '/includes/header.php';
?>
<section style="padding-top:70px;">
  <div class="container">
    <div class="form-card">
      <div class="section-head center" style="margin-bottom:24px;">
        <span class="eyebrow">เริ่มต้นใช้งาน</span>
        <h2>สมัครสมาชิก</h2>
        <span class="pole-underline"></span>
      </div>

      <?php foreach ($errors as $err): ?>
        <div class="alert alert-error"><?= h($err) ?></div>
      <?php endforeach; ?>

      <form method="post" action="register.php" novalidate>
        <input type="hidden" name="csrf_token" value="<?= h(csrfToken()) ?>">

        <div class="field">
          <label>ชื่อ-นามสกุลจริง</label>
          <input type="text" name="full_name" value="<?= h($values['full_name']) ?>" required>
        </div>
        <div class="field">
          <label>อีเมล</label>
          <input type="email" name="email" value="<?= h($values['email']) ?>" required>
        </div>
        <div class="field-row">
          <div class="field">
            <label>อายุ</label>
            <input type="number" name="age" min="15" max="100" value="<?= h($values['age']) ?>" required>
          </div>
          <div class="field">
            <label>เบอร์โทรศัพท์</label>
            <input type="tel" name="phone" placeholder="0812345678" value="<?= h($values['phone']) ?>" required>
          </div>
        </div>
        <div class="field-row">
          <div class="field">
            <label>รหัสผ่าน</label>
            <input type="password" name="password" required>
          </div>
          <div class="field">
            <label>ยืนยันรหัสผ่าน</label>
            <input type="password" name="password_confirm" required>
          </div>
        </div>

        <button type="submit" class="btn btn-primary btn-block">สมัครสมาชิก</button>
      </form>

      <div class="form-foot">
        มีบัญชีอยู่แล้ว? <a href="login.php">เข้าสู่ระบบ</a>
      </div>
    </div>
  </div>
</section>
<?php require_once __DIR__ . '/includes/footer.php'; ?>
