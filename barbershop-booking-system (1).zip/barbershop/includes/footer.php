<div class="pole-divider"></div>
<footer>
  <div class="container">
    <div class="footer-grid">
      <div>
        <h4 class="brand" style="font-size:20px;">THE <span style="color:var(--brass);">BARBER</span> STUDIO</h4>
        <p><?= h(SHOP_TAGLINE) ?></p>
        <p><?= h(SHOP_ADDRESS) ?></p>
      </div>
      <div>
        <h4>ติดต่อร้าน</h4>
        <p>โทร: <?= h(SHOP_PHONE) ?></p>
        <p>LINE: <?= h(SHOP_LINE_ID) ?></p>
        <p><?= h(SHOP_OPEN_HOURS) ?></p>
      </div>
      <div>
        <h4>เมนูลัด</h4>
        <a href="<?= BASE_URL ?>/gallery.php">แกลเลอรี่ผลงาน</a>
        <a href="<?= BASE_URL ?>/services.php">รายการ &amp; จองคิว</a>
        <a href="<?= BASE_URL ?>/register.php">สมัครสมาชิก</a>
      </div>
    </div>
    <div class="footer-bottom">
      &copy; <?= date('Y') ?> <?= h(SHOP_NAME) ?> — โครงงานระบบจองคิวร้านตัดผม
    </div>
  </div>
</footer>
<script src="<?= BASE_URL ?>/assets/js/main.js"></script>
</body>
</html>
