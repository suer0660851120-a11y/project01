<?php
/**
 * includes/functions.php
 * ฟังก์ชันช่วยเหลือที่ใช้ร่วมกันทั้งระบบ
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';

/** ทำความสะอาด input ก่อนแสดงผล ป้องกัน XSS */
function h(?string $str): string
{
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

/** เช็คว่าล็อกอินอยู่หรือไม่ */
function isLoggedIn(): bool
{
    return isset($_SESSION['user_id']);
}

/** เช็คว่าเป็นแอดมินหรือไม่ */
function isAdmin(): bool
{
    return isLoggedIn() && !empty($_SESSION['is_admin']);
}

/** บังคับให้ต้องล็อกอินก่อนถึงจะเข้าหน้านี้ได้ (ใช้กับหน้าจองคิว) */
function requireLogin(string $redirectTo = 'login.php'): void
{
    if (!isLoggedIn()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? '';
        header('Location: ' . $redirectTo);
        exit;
    }
}

/** บังคับสิทธิ์แอดมิน */
function requireAdmin(): void
{
    if (!isAdmin()) {
        header('Location: ../login.php');
        exit;
    }
}

/** ดึงข้อมูลผู้ใช้ปัจจุบันจากฐานข้อมูล */
function currentUser(): ?array
{
    if (!isLoggedIn()) {
        return null;
    }
    $db = getDB();
    $stmt = $db->prepare('SELECT id, full_name, email, phone, age, is_admin FROM users WHERE id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    return $user ?: null;
}

/** ดึงรายการบริการทั้งหมดที่เปิดใช้งาน เรียงตาม sort_order */
function getActiveServices(): array
{
    $db = getDB();
    $stmt = $db->query('SELECT * FROM services WHERE is_active = 1 ORDER BY sort_order ASC, id ASC');
    return $stmt->fetchAll();
}

/** ดึงรูปแกลเลอรี่ทั้งหมด */
function getGalleryImages(): array
{
    $db = getDB();
    $stmt = $db->query('SELECT * FROM gallery ORDER BY sort_order ASC, id ASC');
    return $stmt->fetchAll();
}

/** จัดรูปแบบราคาเป็นสกุลเงินบาท */
function formatPrice(float $price): string
{
    return number_format($price, 2) . ' บาท';
}

/** สร้าง CSRF token และเก็บใน session */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** ตรวจสอบ CSRF token ที่ส่งมาจากฟอร์ม */
function checkCsrf(string $token): bool
{
    return !empty($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/** ตรวจสอบรูปแบบเบอร์โทรศัพท์ไทยอย่างง่าย (เช่น 0812345678) */
function isValidThaiPhone(string $phone): bool
{
    return (bool) preg_match('/^0[0-9]{8,9}$/', $phone);
}
